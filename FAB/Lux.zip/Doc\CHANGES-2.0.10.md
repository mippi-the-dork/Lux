# Lux 2.0.10 | Compact native split toolbar control

- Reduced Lux icon button horizontal padding and the native chevron's inset so the two controls read as one compact toolbar group.
- Matched the icon toggle and dropdown button to the same 24-Slate-unit height.
- Copied Unreal's native `ComboButton` style into a Lux-owned per-widget style before adjusting `DownArrowPadding`; no global editor style overrides.
- Preserved the supplied 2.0.9 toolbar SVG, active/inactive coloring, independently clickable controls, first-in-right-section toolbar placement, menus, and light behavior.

**Validation:** Source-level structural checks only; validate against Unreal Engine 5.8.3 on Windows.
