# Lux 2.0.7 | Consolidated Advanced Menu

- Reduced the main Lux dropdown to Intensity, Attenuation Radius, Light Color, Cast Shadows, Advanced, and the two actions.
- Moved Source Radius and Volumetric Scattering Intensity from the main menu into Advanced.
- Removed the redundant ADVANCED submenu heading; used native Lighting and Temperature section headers.
- Decreased submenu property-row width from 368 to 328 Slate units, while keeping long UE property names readable.
- Added Indirect Lighting Intensity (0 to 6, default 1) and Affect Translucent Lighting (enabled by default) as native point-light controls.
- Added corresponding project defaults, per-user preferences, apply/reset support and one-time preferences migration.
- Kept the toolbar's correct first position in the right-anchored section and all existing viewport behavior.
- Updated README and testing instructions.

Validation: Source/archive reviewed; Unreal Editor 5.8 C++ compilation and runtime UI tests must be performed in a local engine installation.
