# Lux 2.0.4 | Left-edge toolbar placement fix

Lux 2.0.3 placed the control in the viewport toolbar's `Right` section, anchoring it to Link's dynamic entry or the camera menu. That reordered controls only inside the right-aligned section, leaving Lux near the far-right end of the toolbar.

- Register the Lux widget in the native `Left` section instead of `Right`.
- Request `EToolMenuInsertType::First` to lead the left-side toolbar group.
- Remove the Link-specific entry anchor and unused plugin lookup.
- Keep the UI appearance, settings, and headlamp functionality unchanged.

## Validation

Source and archive structure inspected. Unreal Engine 5.8.3 was not available in the packaging environment for compilation or in-editor layout verification. Confirm placement on a real Level Editor viewport at different widths and layouts, and with Link enabled and disabled.
