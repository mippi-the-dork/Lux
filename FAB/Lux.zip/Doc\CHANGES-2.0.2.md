# Lux 2.0.2 | Native UI and settings navigation

- Matched native UE 5.8 checked/hover toolbar behavior using the application toggle-checkbox style. Inactive icon now uses the regular foreground color for legibility, active icon remains Accent Blue.
- Restyled the adjacent dropdown with the native SimpleButton style to reduce the oversized boxed-arrow appearance.
- Replaced the hand-built popup header and action buttons with native `FMenuBuilder` section headings, separators, and actionable menu entries.
- Aligned numeric controls, color swatch and checkboxes in a compact two-column Details-like grid. Reduced color swatch dimensions; added cm/K unit labels.
- Configured numeric value display to omit unnecessary trailing zeros while allowing up to two decimal places.
- Kept the native color picker and Advanced expandable area, with temperature properly conditionally editable.
- Fixed the Project Settings navigation target by explicitly overriding `ULuxProjectSettings::GetContainerName()`, `GetCategoryName()`, and `GetSectionName()` to `Project`, `Plugins`, and `Lux`. Previously the implicit section identifier was `LuxProjectSettings`, but the UI requested `Lux`; the mismatched target left users on the Project Settings landing page.
- No changes to light creation, viewport tracking, or user settings persistence.

## Validation status

Source-level API checks completed against UE 5.8 documentation; local UE 5.8.3 compile and runtime tests remain required. This package is a full `Lux/` folder replacement.
