# Lux 2.0.9 | Toolbar icon update

Replaced the Lux **toolbar button SVG only**, using the new artwork supplied by the plugin author.

- Retained the existing `Resources/Lux.svg` resource path and existing vector brush registration.
- Converted Adobe Illustrator SVG class-based white fills to explicit SVG path fills for robust Slate rendering. The vector path geometry was not changed.
- Retained the existing inactive gray and active Unreal Accent Blue tinting.
- No changes to toolbar placement, dropdown, settings, lighting behavior, or viewport tracking.

The new icon uses the existing toolbar's 16 × 16 Slate vector brush sizing.
