# Lux 2.0.10 | UE 5.8.3 Testing Checklist

This source package requires validation in an installed Windows Unreal Engine 5.8.3 editor. Packaging and source checks do not replace a clean Editor build or runtime testing.

## Build and native integration

- [ ] Build Lux under UE 5.8.3 without C++ or UHT errors.
- [ ] Open the editor with no Lux-specific load errors or Slate style warnings.
- [ ] Confirm the supplied SVG is gray when inactive and Accent Blue when active, without a solid checked-button background.
- [ ] Toggle Lux with the icon; open the menu with the adjacent arrow. Verify hover, focus, Escape, and click-outside behavior.
- [ ] Confirm Lux is the **leftmost entry of the right-anchored viewport toolbar group**, not on the global left toolbar. Check after restart, viewport layout changes, and with Link enabled or disabled.
- [ ] Verify Lux has no dependency on UMG, Blutility, Editor Utility Widgets, Blueprint content or Metric.

## Main flyout and Advanced submenu

- [ ] Confirm the main Lux menu is noticeably narrower than in 2.0.7, while its numeric controls remain full width and right-aligned.
- [ ] Confirm **Intensity**, **Attenuation Radius**, **Light Color**, and **Cast Shadows** fit without clipping at default editor DPI/font scale.
- [ ] Confirm **Advanced** remains a normal Unreal flyout submenu with the native hover/focus highlight and chevron.
- [ ] Confirm Advanced retains its independent wider width; all seven labels fit, especially **Volumetric Scattering Intensity** and **Affect Translucent Lighting**.
- [ ] Confirm the Advanced submenu contains native **Lighting** and **Temperature** sections, with no redundant "Advanced" section header.
- [ ] Confirm property labels, numeric fields, checkboxes, swatch, and cm/K units align within each menu.
- [ ] Confirm numeric scrubbing works, including at the min/max of Intensity and Radius.
- [ ] Confirm **Temperature** is disabled when **Use Temperature** is unchecked and enabled when checked.
- [ ] Confirm **Reset to Project Defaults** and **Lux Project Settings** remain visible in the main menu, separated from properties by a native divider.
- [ ] Confirm the project-settings action opens **Project Settings > Plugins > Lux** directly, not the generic settings root.
- [ ] Check submenu position near the right edge of the monitor and with the Outliner adjacent; normal Slate placement may overlap editor panels.
- [ ] Check at 100%, 125% and 150% Windows display scaling if available; no text or control clipping.

## Lighting and viewport behavior

- [ ] Toggle light on/off, including with no active Level Editor viewport.
- [ ] Navigate in a perspective viewport; the single headlamp follows that camera.
- [ ] Click between two perspective viewports; the last interacted viewport takes ownership.
- [ ] Switch to an orthographic viewport; the headlamp does not jump to its camera.
- [ ] Test viewport layout changes, maximize/restore, level changes, PIE and Simulate, and plugin shutdown.
- [ ] Confirm no Lux light is saved into the level or shipped in cooked builds.
- [ ] Confirm other lit Level Editor viewports may see the shared-world light (expected, not per-viewport isolated).

## Properties and persistence

- [ ] Adjust Intensity/Attenuation Radius by typing and scrubbing; test project-configured min/max values.
- [ ] Adjust Light Color in Unreal's native color picker and toggle Cast Shadows.
- [ ] Adjust Source Radius and Volumetric Scattering Intensity; renderer-dependent effects may vary.
- [ ] Adjust Indirect Lighting Intensity and Affect Translucent Lighting in a scene/rendering path that supports them.
- [ ] Adjust Specular Scale and Temperature; test expected disabling when Use Temperature is off.
- [ ] Set project defaults under **Plugins > Lux**, then reset Lux and verify all fields use those defaults.
- [ ] Confirm default Attenuation Radius displays centimeter units in Project Settings.
- [ ] Restart the editor: Lux starts disabled and per-user numeric/color preferences persist.
- [ ] Upgrade a 2.0.7 installation and verify saved values survive unchanged.

If the build fails, capture Lux-only compiler messages and any relevant UE 5.8.3 engine headers.

## Lux 2.0.9 toolbar icon check

- Verify the new sun-ray icon appears at the left edge of the right-anchored viewport toolbar section.
- Verify the SVG is clearly visible in gray when disabled and Unreal Accent Blue when enabled.
- Verify the toolbar toggle and dropdown arrow still work independently.
- Confirm this icon update has not changed any controls or the light's behavior.


## Lux 2.0.10 compact toolbar validation

- [ ] Toggle and settings chevron have matching visual and hover heights.
- [ ] Icon and chevron are close together, with no oversized space between the two hit targets.
- [ ] Clicking the icon toggles Lux without opening the menu.
- [ ] Clicking the chevron opens the menu without toggling Lux.
- [ ] The controls remain aligned at 100% and higher editor DPI scaling, when active and inactive.
- [ ] The new 2.0.9 SVG remains unchanged; inactive is gray, active is Unreal Accent Blue.
- [ ] Lux stays first in the right-anchored viewport toolbar group.
