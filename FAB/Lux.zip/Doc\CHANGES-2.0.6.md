# Lux 2.0.6

## Native menu polish

- Kept Lux in the correct right-anchored toolbar position as the first control in that group.
- Refined the dropdown menu to better match Unreal Engine 5 viewport menu behavior.
- Replaced the custom in-place Advanced expandable area with a native Advanced submenu.
- Tightened row padding and width slightly to better match the rhythm of native viewport menus.
- Slightly increased the color swatch height for a more native property-row feel.

This pass is focused on UX and visual behavior only. The lighting system and viewport tracking are unchanged.
