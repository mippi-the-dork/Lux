# Lux 2.0.3 | Viewport UI polish

This is a focused UI-only release. The headlamp, light properties, viewport tracking and configuration behavior are unchanged.

- **Toolbar placement:** Uses Link's exact registered `LinkViewportControls` ToolMenus entry as the optional insertion anchor, rather than competing with Link for the same `Camera` anchor. Falls back to native `Camera` when Link is not enabled. Does not add a Link module dependency.
- **Toggle presentation:** Uses Unreal's native `SimpleButton` style instead of its blue-background `ToggleButtonCheckbox`. The vector icon is gray when inactive and Accent Blue when active, with standard hover, pressed, focus and keyboard behavior.
- **Popup layout:** Increases the property row width from 326 to 370 Slate units to accommodate `Volumetric Scattering Intensity` without clipping. Expands the Light Color swatch to match the value column.
- **Menu separation:** Adds a native separator before Reset to Project Defaults and Lux Project Settings.
- **Existing native conventions preserved:** Full-range Specular Scale spinbox fill at 1.0 and radius `cm` metadata already match Unreal's generated Details/Project Settings behavior.

## Validation

Source inspected and checked for consistency, but the authoring environment does not contain UE 5.8.3 and cannot compile or render-test this revision. Test against the included `TESTING.md` list.
