# Lux 2.0.5 | Right-anchored toolbar placement correction

Lux 2.0.4 mistakenly inserted Lux into the viewport toolbar's `Left` section. This placed Lux beside the transform/navigation controls on the far left of the viewport, while the requested position is the *leftmost control of the right-aligned group*.

- Register in `LevelEditor.ViewportToolbar` > `Right`, not `Left`.
- Insert the Lux entry with `FToolMenuInsert(NAME_None, EToolMenuInsertType::First)` so it leads the **right-hand group**.
- Avoid relative insertion before `Camera` or the Link plugin's dynamic entry. These anchors previously placed Lux farther toward the end of the group.
- Keep all icon, Slate popup, settings, viewport tracking and lighting behavior unchanged.

## Expected placement

`[left-aligned tools]    [flexible empty space]    [Lux][other right-side tools][Perspective] ...`

The right-hand group stays pinned to the right edge as viewport width changes; Lux remains at the group's left edge.

## Verification

Source and ZIP have been checked. UE 5.8.3 compilation and in-editor layout testing still need to be performed. Confirm position with Link installed and without Link, after editor restart, in maximized/multiple viewports, and in narrow widths.
