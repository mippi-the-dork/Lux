# Lux 2.0.1 | Compile correction for UE 5.8.3

- Replaced nonexistent `Widgets/Layout/SHorizontalBox.h` and `Widgets/Layout/SVerticalBox.h` headers with UE5's shared `Widgets/SBoxPanel.h` header.
- Fixed a stray, uncaptured `Property` reference in the light color row. The color swatch remains editable when Use Temperature is on, matching native Unreal light behavior.
- No changes to plugin dependencies or intended Lux light behavior.

Source-level verification only: UE 5.8.3 compile and runtime testing remain required.
