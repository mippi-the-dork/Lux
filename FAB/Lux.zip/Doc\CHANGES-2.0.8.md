# Lux 2.0.8 | Native viewport menu proportion pass

## UI

- Reduced the **main dropdown** property-row width from 368 to 320 Slate units to remove the excess gap between short property labels and their values.
- Left the main value column at 124 units so numeric controls, color swatch, and checkbox alignment are preserved.
- Kept the **Advanced submenu** at its existing independent 328-unit property-row width and 104-unit value column. Long property labels still have the space they require.
- Preserved the correct first position in the **right-anchored** viewport toolbar group, as well as the icon colors, all controls and lighting functionality.

## Documentation

- Updated the current README and replaced outdated/contradictory test instructions with a unified UE 5.8.3 verification checklist.

## Validation status

- Source/config/package integrity checked. Full Unreal Engine 5.8.3 compilation and visual interaction tests remain to be performed in an editor installation.
